package com.example.joeclancyproject2option1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Switch;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Arrays;

public class UserEditActivity extends AppCompatActivity {

    private Switch adminSwitch;
    private Switch managerSwitch;
    private Switch userSwitch;
    private ImageButton backButton;
    private Button confirmButton;

    private String[] userGroups;
    private String userName;
    private String targetUser;
    private String[] targetGroups;
    private String[] updatedGroups;

    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_edit);

        adminSwitch = findViewById(R.id.switchAdmin);
        managerSwitch = findViewById(R.id.switchManager);
        userSwitch = findViewById(R.id.switchUser);
        confirmButton = findViewById(R.id.editUserConfirm);
        backButton = findViewById(R.id.userEditBackButton);

        // Get username and groups
        InventoryManager app = (InventoryManager) getApplication();
        userGroups = app.getUserGroups();
        userName = app.getUserName();

        // Retrieve item data passed from the previous activity
        Intent intent = getIntent();
        targetUser = intent.getStringExtra("USERNAME");

        // Query current groups for target user
        db = new DatabaseHelper(this);
        targetGroups = db.getUserGroups(targetUser);

        // Configure switches
        adminSwitch.setChecked(Arrays.asList(targetGroups).contains("admin"));
        managerSwitch.setChecked(Arrays.asList(targetGroups).contains("manager"));
        userSwitch.setChecked(Arrays.asList(targetGroups).contains("user"));

        // Unique case to prevent removing admin group from default admin account
        adminSwitch.setEnabled(!targetUser.equals("admin"));

        // Confirm button functionality
        confirmButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ArrayList<String> updatedGroups = new ArrayList<>();

                // Enforce at least one user group
                if (!(adminSwitch.isChecked() || managerSwitch.isChecked() || userSwitch.isChecked())) {
                    Toast.makeText(UserEditActivity.this, "Users must be in at least one group.", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Get updated permissions
                if (adminSwitch.isChecked()) updatedGroups.add("admin");
                if (managerSwitch.isChecked()) updatedGroups.add("manager");
                if (userSwitch.isChecked()) updatedGroups.add("user");

                // Convert arraylist back to type db expects
                String[] updatedGroupsArray = updatedGroups.toArray(new String[0]);

                // Push permissions to database
                if (db.updateUserGroups(targetUser, updatedGroupsArray)) {
                    // Update current user permissions in case they were the same user
                    app.setUserGroups(db.getUserGroups(userName));

                    // Return to groups edit activity
                    finish();

                } else {
                    Toast.makeText(UserEditActivity.this, "Permissions update failed.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Back button
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Go back to the previous activity
            }
        });
    }

}