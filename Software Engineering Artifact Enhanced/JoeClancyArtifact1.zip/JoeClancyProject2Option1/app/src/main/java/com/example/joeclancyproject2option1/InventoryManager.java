package com.example.joeclancyproject2option1;
import android.app.Application;

public class InventoryManager  extends Application {
    private String[] userGroups;
    private String userName;

    // Getter for userGroups
    public String[] getUserGroups() {
        return userGroups;
    }

    // Setter for userGroups
    public void setUserGroups(String[] userGroups) {
        this.userGroups = userGroups;
    }

    // Getter for userName
    public String getUserName() {
        return userName;
    }

    // Setter for userName
    public void setUserName(String userName) {
        this.userName = userName;
    }
}