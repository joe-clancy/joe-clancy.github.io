package com.example.joeclancyproject2option1;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;

public class DataAddActivity extends AppCompatActivity {

    private TextInputEditText itemNameEditText;
    private TextInputEditText itemQuantityEditText;
    private ImageButton backButton, plusButton, minusButton, confirmButton;

    private int itemQuantity = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_add);

        // Initialize views
        itemNameEditText = findViewById(R.id.editADdItemQty); // Note the typo in the ID
        itemQuantityEditText = findViewById(R.id.editAddItemQty);
        backButton = findViewById(R.id.btnAddItemBack);
        plusButton = findViewById(R.id.btnAddItemPlus);
        minusButton = findViewById(R.id.btnAddItemMinus);
        confirmButton = findViewById(R.id.btnAddItemConfirm);

        // Set default item quantity in the TextInputEditText
        itemQuantityEditText.setText(String.valueOf(itemQuantity));

        // Set up button click listeners
        setButtonListeners();
    }

    private void setButtonListeners() {
        // Back button
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Go back to the previous activity
            }
        });

        // Plus button
        plusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                itemQuantity++;
                itemQuantityEditText.setText(String.valueOf(itemQuantity));
            }
        });

        // Minus button
        minusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (itemQuantity > 0) {
                    itemQuantity--;
                    itemQuantityEditText.setText(String.valueOf(itemQuantity));
                } else {
                    Toast.makeText(DataAddActivity.this, "Quantity cannot be less than 0", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Confirm button
        confirmButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String itemName = itemNameEditText.getText().toString();
                String quantityText = itemQuantityEditText.getText().toString();

                if (itemName.isEmpty()) {
                    Toast.makeText(DataAddActivity.this, "Please enter the item name", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (quantityText.isEmpty() || itemQuantity <= 0) {
                    Toast.makeText(DataAddActivity.this, "Please enter a valid item quantity", Toast.LENGTH_SHORT).show();
                    return;
                }

                int quantity = Integer.parseInt(quantityText);

                // Add the item to the database
                DatabaseHelper dbHelper = new DatabaseHelper(DataAddActivity.this);
                boolean isInserted = dbHelper.insertInventoryItem(itemName, quantity);

                if (isInserted) {
                    Toast.makeText(DataAddActivity.this, "Item added successfully", Toast.LENGTH_SHORT).show();
                    finish(); // Go back to the previous activity
                } else {
                    Toast.makeText(DataAddActivity.this, "Failed to add item", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}