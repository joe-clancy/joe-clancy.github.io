package com.example.joeclancyproject2option1;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.ImageButton;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

public class GroupsEditActivity extends AppCompatActivity {

    public static final int TABLE_CELL_PADDING = 8;
    public static final int USERNAME_COLUMN_INDEX = 1;
    public static final int USER_GROUPS_COLUMN_INDEX = 3;
    public static final int USERID_COLUMN_INDEX = 0;

    private TableLayout tableLayout;
    private FloatingActionButton addItemFab;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_groups_edit);

        // Initialize views
        tableLayout = findViewById(R.id.tableLayout);
        dbHelper = new DatabaseHelper(this);

        // Load data from the database
        loadUsers();

        // Set up settings button
        ImageButton backButton = findViewById(R.id.groupsBackButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Intent to go to the back to the data display
                Intent intent = new Intent(GroupsEditActivity.this, DataDisplayActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Reload the inventory items when the activity is resumed
        loadUsers();
    }

    private void loadUsers() {
        // Clear existing rows
        tableLayout.removeViews(1, tableLayout.getChildCount() - 1); // Keep the header row

        // Retrieve items from the database
        Cursor cursor = dbHelper.getAllUsers();
        if (cursor != null && cursor.getCount() > 0) {
            while (cursor.moveToNext()) {
                addItemToTable(cursor.getString(USERNAME_COLUMN_INDEX), cursor.getString(USER_GROUPS_COLUMN_INDEX), cursor.getInt(USERID_COLUMN_INDEX)); // Name, Groups, ID
            }
            cursor.close();
        } else {
            // No items found
            Toast.makeText(this, "No users found. This shouldn't happen!", Toast.LENGTH_SHORT).show();
        }
    }

    private void addItemToTable(String userName, String userGroups, int userId) {
        TableRow row = new TableRow(this);

        // Column 1, username
        TextView nameTextView = new TextView(this);
        nameTextView.setText(userName);
        nameTextView.setPadding(TABLE_CELL_PADDING, TABLE_CELL_PADDING, TABLE_CELL_PADDING, TABLE_CELL_PADDING);

        // Column 2, groups
        TextView quantityTextView = new TextView(this);
        quantityTextView.setText(userGroups);
        quantityTextView.setPadding(TABLE_CELL_PADDING, TABLE_CELL_PADDING, TABLE_CELL_PADDING, TABLE_CELL_PADDING);

        // Column 3, more options button
        ImageButton moreOptionsButton = new ImageButton(this);
        moreOptionsButton.setImageResource(R.drawable.ic_more_vert);
        moreOptionsButton.setBackgroundResource(android.R.color.transparent);
        moreOptionsButton.setPadding(TABLE_CELL_PADDING, TABLE_CELL_PADDING, TABLE_CELL_PADDING, TABLE_CELL_PADDING);

        // Set the click listener for the more options button
        moreOptionsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMoreOptions(userId, userName, userGroups);
            }
        });

        // Assemble new row
        row.addView(nameTextView);
        row.addView(quantityTextView);
        row.addView(moreOptionsButton);

        tableLayout.addView(row);
    }

    private void showMoreOptions(int userId, String userName, String userGroups) {
        // Intent to go to the Data Edit Activity
        Intent intent = new Intent(GroupsEditActivity.this, UserEditActivity.class);
        intent.putExtra("USERNAME", userName);
        startActivity(intent);
    }
}