package com.example.joeclancyproject2option1;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;

import java.util.concurrent.atomic.AtomicInteger;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;
import android.widget.ImageButton;
import android.widget.Switch;
import android.widget.Toast;

public class SMSNotificationActivity extends AppCompatActivity {

    private static final AtomicInteger requestCodeGenerator = new AtomicInteger();

    private int requestCode;
    private Switch notificationsSwitch;
    private ImageButton backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_smsnotification);
        requestCode = requestCodeGenerator.getAndIncrement();

        // Initialize views
        backButton = findViewById(R.id.settingsBackButton);
        notificationsSwitch = findViewById(R.id.switch_notifications);

        // Set switch state based on permissions
        notificationsSwitch.setChecked(checkSMSPermissions(true,false));

        // Set up the back button click listener
        backButton.setOnClickListener(v -> finish());

        // Set up the switch listener
        notificationsSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            // If we require permissions and do not have them, request them
            if (isChecked && !checkSMSPermissions(true,false)) {
                ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.SEND_SMS},requestCode);
                // Temporarily disable the switch to prevent further toggles
                notificationsSwitch.setEnabled(false);
            }
        });
    }

    // Handle the result of the permission request
    @Override
    public void onRequestPermissionsResult(int currRequestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (currRequestCode == requestCode) {
            // Re-enable the switch
            notificationsSwitch.setEnabled(true);

            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, enable notifications
                notificationsSwitch.setChecked(true);
                Toast.makeText(this, "SMS Notifications Enabled", Toast.LENGTH_SHORT).show();
            } else {
                // Permission denied, disable notifications
                notificationsSwitch.setChecked(false);
                Toast.makeText(this, "Permission denied, SMS Notifications Disabled", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public boolean checkSMSPermissions(boolean send, boolean receive) {
        // Returns permission state based on parameters
        if (send && receive) {
            return ContextCompat.checkSelfPermission(this, android.Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED
                    && ContextCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED;
        } else if (send) {
            return ContextCompat.checkSelfPermission(this, android.Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
        } else if (receive) {
            return ContextCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED;
        } else {
            return false;
        }
    }
}