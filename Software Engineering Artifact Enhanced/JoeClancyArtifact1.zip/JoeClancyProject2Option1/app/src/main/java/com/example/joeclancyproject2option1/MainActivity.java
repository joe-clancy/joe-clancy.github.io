package com.example.joeclancyproject2option1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText usernameEditText, passwordEditText;
    Button loginButton, createAccountButton;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new DatabaseHelper(this);

        // Initialize views
        usernameEditText = findViewById(R.id.username);
        passwordEditText = findViewById(R.id.password);
        loginButton = findViewById(R.id.login_button);
        createAccountButton = findViewById(R.id.create_account_button);

        // Log in button
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();


                if (db.checkUser(username, password)) {
                    Toast.makeText(MainActivity.this, "Login successful", Toast.LENGTH_SHORT).show();

                    // Store user permissions in global
                    InventoryManager app = (InventoryManager) getApplication();
                    app.setUserGroups(db.getUserGroups(username));
                    app.setUserName(username);

                    // Navigate to data display
                    Intent intent = new Intent(MainActivity.this, DataDisplayActivity.class);
                    startActivity(intent);

                    // Close login screen
                    finish();
                } else {
                    Toast.makeText(MainActivity.this, "Login failed. Invalid username or password.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Create account button
        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                // Validate inputs exist
                if (username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                } else {
                    boolean result = db.insertUser(username, password);
                    if (result) {
                        Toast.makeText(MainActivity.this, "Sign up successful", Toast.LENGTH_SHORT).show();

                        // Store user permissions in global
                        InventoryManager app = (InventoryManager) getApplication();
                        app.setUserGroups(db.getUserGroups(username));
                        app.setUserName(username);

                        // Navigate to data display
                        Intent intent = new Intent(MainActivity.this, DataDisplayActivity.class);
                        startActivity(intent);

                        // Close login screen
                        finish();
                    } else {
                        Toast.makeText(MainActivity.this, "Sign up failed", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}