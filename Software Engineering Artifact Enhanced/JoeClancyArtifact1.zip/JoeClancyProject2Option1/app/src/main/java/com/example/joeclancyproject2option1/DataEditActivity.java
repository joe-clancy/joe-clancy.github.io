package com.example.joeclancyproject2option1;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import android.content.SharedPreferences;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.textfield.TextInputEditText;

import java.util.Arrays;

public class DataEditActivity extends AppCompatActivity {

    private TextView itemNameTextView;
    private TextInputEditText itemQuantityEditText;
    private ImageButton backButton, plusButton, minusButton, confirmButton, deleteButton;

    private SharedPreferences sharedPreferences;
    private DatabaseHelper dbHelper;
    private int itemId;
    private String itemName;
    private int itemQuantity;
    private String[] userGroups;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_edit);

        // Initialize views
        itemNameTextView = findViewById(R.id.textManageItemName);
        itemQuantityEditText = findViewById(R.id.editManageItemQty);
        backButton = findViewById(R.id.btnManageItemBack);
        plusButton = findViewById(R.id.btnManageItemPlus);
        minusButton = findViewById(R.id.btnManageItemMinus);
        confirmButton = findViewById(R.id.btnManageItemConfirm);
        deleteButton = findViewById(R.id.btnManageItemTrash);

        dbHelper = new DatabaseHelper(this);

        // Retrieve item data passed from the previous activity
        Intent intent = getIntent();
        itemId = intent.getIntExtra("ITEM_ID", -1);
        itemName = intent.getStringExtra("ITEM_NAME");
        itemQuantity = intent.getIntExtra("ITEM_QUANTITY", 0);

        // Set the item data to the views
        itemNameTextView.setText(itemName);
        itemQuantityEditText.setText(String.valueOf(itemQuantity));

        InventoryManager app = (InventoryManager) getApplication();
        userGroups = app.getUserGroups();

        // disable deleting items for non-manager/admin members
        if (Arrays.asList(userGroups).contains("manager") || Arrays.asList(userGroups).contains("admin")) {
            deleteButton.setVisibility(View.VISIBLE); // Show button if the user is an admin or manager
        } else {
            deleteButton.setVisibility(View.INVISIBLE); // Hide button if the user is not an admin or manager
        }


        // Set up button click listeners
        setButtonListeners();
    }

    private void setButtonListeners() {
        // Back button
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Go back to the previous activity
            }
        });

        // Plus button
        plusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                itemQuantity++;
                itemQuantityEditText.setText(String.valueOf(itemQuantity));
            }
        });

        // Minus button
        minusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (itemQuantity > 0) {
                    itemQuantity--;
                    itemQuantityEditText.setText(String.valueOf(itemQuantity));
                } else {
                    Toast.makeText(DataEditActivity.this, "Quantity cannot be less than 0", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Confirm button
        confirmButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String updatedQuantityText = itemQuantityEditText.getText().toString();
                int updatedQuantity = Integer.parseInt(updatedQuantityText);
                boolean isSmsNotificationsEnabled = ContextCompat.checkSelfPermission(DataEditActivity.this, android.Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;

                boolean isUpdated = dbHelper.updateInventoryItem(itemId, itemName, updatedQuantity);

                // Update was successful
                if (isUpdated) {
                    // If quantity has reached 0, send SMS notification
                    if (updatedQuantity < 1 && isSmsNotificationsEnabled) {
                        boolean result = sendSMSMessage("1234567890", itemName);

                        // Report success or failure of SMS send
                        if (result) {
                            Toast.makeText(DataEditActivity.this, "SMS Sent", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(DataEditActivity.this, "SMS failed to send", Toast.LENGTH_SHORT).show();
                        }
                    }

                    finish(); // Go back to the previous activity
                } else {
                    // Update failed without crashing the app, toast a message
                    Toast.makeText(DataEditActivity.this, "Failed to update item", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Delete button
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Delete itemId from the database
                boolean isDeleted = dbHelper.deleteInventoryItem(itemId);
                if (isDeleted) {
                    finish(); // Go back to the previous activity
                } else {
                    // Something has gone wrong without crashing the app, toast a message
                    Toast.makeText(DataEditActivity.this, "Failed to delete item", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private boolean sendSMSMessage(String phoneNumber, String itemName) {
        String message = "You have 0 " + itemName + " left in inventory.";
        // Attempt to send SMS message
        try {
            SmsManager smsManager = this.getSystemService(SmsManager.class);
            smsManager.sendTextMessage(phoneNumber,null,message,null,null);
            return true;
        // Report failure
        } catch (Exception ex) {
            return false;
        }
    }
}

